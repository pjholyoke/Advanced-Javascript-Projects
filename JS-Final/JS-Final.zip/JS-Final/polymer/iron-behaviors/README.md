
<!---

This README is automatically generated from the comments in these files:
iron-button-state.html  iron-control-state.html

Edit those files, and our readme bot will duplicate them over here!
Edit this file, and the bot will squash your changes :)

The bot does some handling of markdown. Please file a bug if it does the wrong
thing! https://github.com/PolymerLabs/tedium/issues

-->

[![Build status](https://travis-ci.org/PolymerElements/iron-behaviors.svg?branch=master)](https://travis-ci.org/PolymerElements/iron-behaviors)

_[Demo and API docs](https://elements.polymer-project.org/elements/iron-behaviors)_


<!-- No docs for Polymer.IronButtonState found. -->

<!-- No docs for Polymer.IronControlState found. -->
